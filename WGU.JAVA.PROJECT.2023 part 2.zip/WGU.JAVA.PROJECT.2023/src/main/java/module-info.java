/**
 * project module
 * */

module com.example.wgujavaproject {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.wgujavaproject to javafx.fxml;
    exports com.example.wgujavaproject;
}